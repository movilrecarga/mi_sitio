<?php
header("Location: https://./");
exit();
?>